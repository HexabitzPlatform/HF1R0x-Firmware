#define VERSION_MAJOR 1
#define VERSION_MINOR 4


/* #undef USE_TEST_MAIN */
