#define VERSION_MAJOR       1
#define VERSION_MINOR       5


/* #undef USE_TEST_MAIN */
